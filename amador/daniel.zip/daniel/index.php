<?php include("./includes/head.php"); ?>
<?php include("./includes/superior.php"); ?>
        
        <tr id="ofertas" bgcolor="orange"  >
            <td rowspan="6">NAVEGADOR LATERAL</td>
            <td>
                <p> <a href="productos.php">OFERTA 1</a></p>
            </td>
            <td>
                <p> OFERTA 2</p>
            </td>
            <td>
                <p> OFERTA 3</p>
            </td>
            <td>
                <p> OFERTA 4</p>
            </td>
            <td>
                <p> OFERTA 5</p>
            </td>
        </tr>
        <tr>
            <td> <p>en blanco</p></td>
           
        </tr>
        <tr id="metal" bgcolor="SteelBlue">
            <td colspan="2">METAL</td>
            <td><p>Ofertametal</p></td>
            <td><p>Ofertametal</p></td>
            <td><p>Ofertametal</p></td>

        </tr>
        <tr id="ceramica" bgcolor="coral">
            <td colspan="2">CERAMICA</td>
            <td><p>Ofertaceramica</p></td>
            <td><p>Ofertaceramica</p></td>
            <td><p>Ofertaceramica</p></td>

        </tr>
        <tr id="madera" bgcolor="tan">
            <td colspan="2">MADERA</td>
            <td><p>Ofertamadera</p></td>
            <td><p>Ofertamadera</p></td>
            <td><p>Ofertamadera</p></td>

        </tr>
        <tr id="etnico" bgcolor="brown">
            <td colspan="2">ETNICO</td>
            <td><p>Ofertaetnico</p></td>
            <td><p>Ofertaetnico</p></td>
            <td><p>Ofertaetnico</p></td>
        </tr>

<?php include("./includes/footer.php"); ?>
