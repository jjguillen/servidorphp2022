<?php include("./includes/head.php"); ?>
<?php include("./includes/superior.php"); ?>
        
        <tr id="ofertas" bgcolor="orange"  >
            <td>NAVEGADOR LATERAL</td>
            <td colspan="5">
                <p> producto</p><br><br><br><br><br><br><br>
            </td>
        </tr>

<?php include("./includes/footer.php"); ?>
