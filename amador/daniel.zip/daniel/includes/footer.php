
        <tr id="footer" bgcolor="#ccc">
            <td colspan="6"><br>ETNICO<br><br><br><br></td>
        </tr>
    </table>
</center>
</body>

</html>
