<tr id="nav" bgcolor="coral">
            <td>
                <p><a href="index.php">Home</a></p>
            </td>
            <td>
                <p>METAL</p>
            </td>
            <td>
                <p>CERAMICA</p>
            </td>
            <td>
                <p>MADERA</p>
            </td>
            <td>
                <p><a href="buscador.php">Buscar</a></p>
            </td>
            <td>
                <p>Idioma</p> 
            </td>
        </tr>
        <tr id="nosotros" bgcolor="olive">
            <td colspan="6">
                <p>TRABAJAMOS TODO TIPO DE MATERIALES </p>
                <p>(u otro eslogan)</p>
            </td>
        </tr>
